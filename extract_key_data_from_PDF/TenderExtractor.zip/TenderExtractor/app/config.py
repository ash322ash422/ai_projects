"""
Central configuration for TenderExtractor.

All values are read from environment variables (or a local .env file).
For the POC, sensible local fallbacks are provided so the app can run
end-to-end on a laptop before Azure credentials are wired up.
"""

from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- App -------------------------------------------------------
    APP_NAME: str = "TenderExtractor"
    ENV: str = "poc"  # poc | dev | prod

    # --- Local storage fallback (used when Azure creds are absent) -
    LOCAL_UPLOAD_DIR: str = "uploads"
    LOCAL_OUTPUT_DIR: str = "output"
    USE_LOCAL_STORAGE_FALLBACK: bool = True

    # --- Azure Blob Storage -----------------------------------------
    AZURE_STORAGE_CONNECTION_STRING: str = ""
    AZURE_STORAGE_CONTAINER_UPLOADS: str = "uploads"
    AZURE_STORAGE_CONTAINER_OUTPUT: str = "output"

    # --- Azure AI Document Intelligence ------------------------------
    AZURE_DOCINTEL_ENDPOINT: str = ""
    AZURE_DOCINTEL_KEY: str = ""
    AZURE_DOCINTEL_MODEL: str = "prebuilt-layout"

    # --- Azure OpenAI --------------------------------------------------
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_KEY: str = ""
    AZURE_OPENAI_API_VERSION: str = "2024-08-01-preview"
    AZURE_OPENAI_DEPLOYMENT: str = "gpt-4.1"
    AZURE_OPENAI_MAX_TOKENS: int = 2000
    AZURE_OPENAI_TEMPERATURE: float = 0.0

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
